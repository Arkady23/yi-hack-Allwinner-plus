var adic=new Map(),cFmt;

adic= { recSd:	["SD-card&nbsp;records","Записи&nbsp;на&nbsp;sd-карте"],
	inFold:	["in the folder","в папке"],
	fmtSD1:	["FORMAT the SD card?","ФОРМАТИРОВАТЬ SD-карту?"],
	fmtSD2:	["All data on the SD card will be deleted!!!","Все данные на sd-карте будут уничтожены!!!"],
	fmt:	["Formatting the sd-card...","Форматирование sd-карты..."],
	time:	["Time<br>(minute)","Время<br>(минута)"],
	fName:	["File name","Имя файла"],
	saveFl:	["Save<br>the file","Сохранить<br>файл"],
	noRec:	["There are no records","Записей нет"],
	ctrlCm:	["Camera control","Управление камерой"],
	safOff:	["Safe shutdown of the camera","Безопасное отключение камеры"],
	camOff:	["The camera shuts down...","Камера отключается..."],
	camSh:	["The camera has shut down","Камера завершила работу"],
	recSdC:	["Camera&nbsp;sd-card&nbsp;records","Записи&nbsp;на&nbsp;sd-картe&nbsp;камеры"],
	date:	["Date and time","Дата и время"],
	fold:	["Folder","Папка"]
	};
cFmt="<a href='javascript:fmtSD()'>"+adic["fmt"][lang]+"</a>"

function main(p){
  document.getElementById("in1").innerHTML="<table style='padding-top:15px'>"+
	"<tr><td><td width=250>"+(p?adic["recSd"][lang]:"<a href='javascript:menu();location.assign(location.protocol+"+
	"\"//\"+location.hostname+\"/al++.html\")'>"+adic["recSd"][lang]+"</a>")+
	"<tr><td><td id='fmt'>"+cFmt+
	"<tr><td><td>"+(p?"<a href='javascript:menu();location.assign(location.protocol+"+
	"\"//\"+location.hostname)'>"+adic["ctrlCm"][lang]+"</a>":adic["ctrlCm"][lang])+
	"<tr><td style='padding:5px 0 0 15px'><a href=\"javascript:power('off')\"><img src=images/poweron.svg width=20></a>"+
	"<td id='off'><a href=\"javascript:power('off')\">"+adic["safOff"][lang]+"</a>"+
	"</table>";
  if(p)sdcard();
}

function go2(){
  let tbody,row,htm,i;
  x=req.responseText;
  var dl=x.lastIndexOf("\t");
  if(dl<0){
    d=["",""];
  }else{
    d=x.split("\t");
    dl=d.length-1;
  }
  switch(d[1]){
  case 'folder':
    tbody=document.getElementById("body1");
    tbody.innerHTML="";
    tbody.className="pl";
    if(dl>1){
      let fldr=d[2],pat="/record/"+d[2]+"/",
        htm="<h3 class='container'><a href='javascript:location.reload()'>"+adic["recSd"][lang]+"</a>\r\n"+
	" "+adic["inFold"][lang]+" "+d[2]+"</h3><hr class='tiny-margin'>\r\n"+
        "<video id=\"video\" class=\"video\" controls autoplay></video>\r\n"+
        "<table><tr><th width=120 class=\"tc\">"+adic["time"][lang]+"<th width=120>"+adic["fName"][lang]+"<th width=100>"+adic["saveFl"][lang]+"\r\n";
      for(i=2;i<dl;){
        htm+="<tr>\r\n"+
          "<td class=\"tc\">"+d[++i].substring(0,2)+
          "<td><a href=\"javascript:document.getElementById('video').setAttribute('src','"+pat+d[i]+"')\">"+d[i]+"</a>\r\n"+
          "<td><a href=\""+pat+d[i]+"\" class=\"f18\">&#128190;</a>";
      }
      htm+="</table>";
      tbody.innerHTML=htm;
    }
    break;
  case 'fmt':
	fstatus('fmt',cFmt);
	menu();
	break;
  default:
    tbody=document.getElementById("body1").getElementsByTagName("TBODY")[0];
    if(dl<2){
      row=document.createElement("TR");
      row.innerHTML="<TD colspan='2' class='tc'>"+adic["noRec"][lang];
      tbody.appendChild(row);
    }else{
      for(i=0;i<dl;){
        row=document.createElement("TR");
        row.innerHTML="<TD class='tc'>"+d[++i]+'<TD>'+d[++i];
        tbody.appendChild(row);
      }
    }
  }
}

function menu(){
  document.getElementById("checkbox").click();
}
function fstatus(id,txt){
  document.getElementById(id).innerHTML=txt;
}
function fmtSD(){
  if(confirm('\n         "+adic["fmtSD1"][lang]+"\n         "+adic["fmtSD2"][lang]+"\n')){
	fstatus('fmt',adic['fmt'][lang]);
	go('cgi-bin/fmtsd.sh');
  }else{
	menu();
  }
}
function power(off){
  if(off=="off"){
    go('cgi-bin/poweroff.sh');
    fstatus('off',adic["camOff"][lang]);
    setTimeout(function(){fstatus('off',adic["camSh"][lang])},15000);
  }
}
function sdcard(){
  let fo=document.getElementById("body1");
  fo.innerHTML="<h3 class='container'>"+adic["recSdC"][lang]+"</h3><hr class='tiny-margin'>\r\n"+
	"<table class='pl'>\r\n"+
	"<tr><th width=250 class='tc'>"+adic["date"][lang]+"<th width=250>"+adic["fold"][lang]+"\r\n"+
	"</table>\r\n";
  go('cgi-bin/sdcard.sh');
}
